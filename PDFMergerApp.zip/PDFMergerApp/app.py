"""Local Streamlit PDF/image merger with explicit document order."""
from __future__ import annotations

from io import BytesIO
from pathlib import Path

import streamlit as st
from PIL import Image, ImageOps
from pypdf import PdfReader, PdfWriter

SUPPORTED = {'.pdf', '.jpg', '.jpeg', '.png'}

st.set_page_config(page_title='PDF & Image Merger', page_icon='📑', layout='wide')
st.title('📑 PDF & Image Merger')
st.caption('Select source documents, arrange their order, and save a bookmarked PDF locally.')


def normalize_folder(value: str) -> Path:
    return Path(value.strip().strip('"').strip("'")).expanduser().resolve()


def list_files(folder: Path) -> list[str]:
    return sorted((p.name for p in folder.iterdir() if p.is_file() and p.suffix.lower() in SUPPORTED), key=str.casefold)


def image_as_pdf(path: Path) -> BytesIO:
    with Image.open(path) as original:
        image = ImageOps.exif_transpose(original).convert('RGBA')
        background = Image.new('RGB', image.size, (255, 255, 255))
        background.paste(image, mask=image.getchannel('A'))
        buffer = BytesIO()
        background.save(buffer, format='PDF', resolution=150.0)
    buffer.seek(0)
    return buffer


def merge_files(folder: Path, filenames: list[str], destination: Path) -> tuple[int, int]:
    writer = PdfWriter()
    buffers: list[BytesIO] = []
    page_count = 0
    try:
        for name in filenames:
            path = (folder / name).resolve()
            if path.parent != folder or not path.is_file() or path.suffix.lower() not in SUPPORTED:
                raise ValueError(f'Invalid source file: {name}')
            if path == destination.resolve():
                raise ValueError('The output cannot overwrite a selected source PDF.')
            if path.suffix.lower() == '.pdf':
                reader = PdfReader(str(path))
                if reader.is_encrypted:
                    raise ValueError(f'Password-protected PDF is not supported: {name}')
                page_count += len(reader.pages)
                writer.append(reader, outline_item=path.stem)
            else:
                buffer = image_as_pdf(path)
                buffers.append(buffer)  # Keep in-memory PDFs open until writer.write().
                writer.append(buffer, outline_item=path.stem)
                page_count += 1
        with destination.open('wb') as output:
            writer.write(output)
        return len(filenames), page_count
    finally:
        writer.close()
        for buffer in buffers:
            buffer.close()


st.subheader('1. Select source folder')
default = str(Path.home() / 'Documents')
source_text = st.text_input('Source folder path', value=default, help='Paste or type an absolute folder path on the computer running Streamlit.')
source = normalize_folder(source_text) if source_text.strip() else None

if source and source.is_dir():
    subfolders = sorted([p for p in source.iterdir() if p.is_dir() and not p.name.startswith('.')], key=lambda p: p.name.casefold())
    nav1, nav2 = st.columns([1, 3])
    with nav1:
        if st.button('⬆ Parent folder'):
            st.session_state['source_override'] = str(source.parent)
    with nav2:
        if subfolders:
            chosen_subdir = st.selectbox('Open subfolder', ['—'] + [p.name for p in subfolders], key=f'subfolders_{source}')
            if chosen_subdir != '—' and st.button('Open selected folder'):
                st.session_state['source_override'] = str(source / chosen_subdir)
    if 'source_override' in st.session_state:
        st.info('Folder navigation: copy this path into the source folder field: ' + st.session_state.pop('source_override'))
elif source:
    st.error('Source folder does not exist. Check the path and permissions.')

st.subheader('2. Select files')
if source and source.is_dir():
    available = list_files(source)
    selected = st.multiselect('Choose PDF/JPEG/JPG/PNG files', available, default=[], key=f'selected_{source}')
    selected_set = set(selected)
    if st.session_state.get('order_source') != str(source):
        st.session_state['order_source'] = str(source)
        st.session_state['ordered_files'] = []
    order = st.session_state['ordered_files']
    order = [f for f in order if f in selected_set]
    order.extend(f for f in selected if f not in order)
    st.session_state['ordered_files'] = order
    if not available:
        st.warning('No supported files found in this folder.')
    st.subheader('3. Arrange merge order')
    st.caption('Top = first in the output PDF. Use the arrows to rearrange files.')
    for idx, filename in enumerate(order):
        left, up, down = st.columns([12, 1, 1])
        left.write(f'**{idx+1}.** {filename}')
        if up.button('↑', key=f'up_{idx}', disabled=(idx == 0), help='Move up'):
            order[idx - 1], order[idx] = order[idx], order[idx - 1]
            st.session_state['ordered_files'] = order
            st.rerun()
        if down.button('↓', key=f'down_{idx}', disabled=(idx == len(order) - 1), help='Move down'):
            order[idx + 1], order[idx] = order[idx], order[idx + 1]
            st.session_state['ordered_files'] = order
            st.rerun()
else:
    order = []

st.subheader('4. Select output folder and filename')
output_text = st.text_input('Output folder path', value=str(Path.home() / 'Documents'), help='Must be an existing folder accessible to Streamlit.')
file_name = st.text_input('Output filename', value='Final_Merged.pdf')
output_dir = normalize_folder(output_text) if output_text.strip() else None
output_name = file_name.strip()
if output_name and not output_name.lower().endswith('.pdf'):
    output_name += '.pdf'
valid_filename = bool(output_name) and Path(output_name).name == output_name and output_name not in {'.', '..'}
destination = output_dir / output_name if output_dir and valid_filename else None
if destination:
    st.caption(f'Output: `{destination}`')

include_bookmarks = st.checkbox('Add bookmarks for each original file', value=True, disabled=True, help='Bookmarks are always included in this version.')

if st.button('Merge selected files', type='primary', disabled=not order, use_container_width=True):
    if not output_dir or not output_dir.is_dir():
        st.error('Output folder does not exist. Select an existing folder.')
    elif not valid_filename:
        st.error('Enter a valid output filename, without path separators.')
    elif destination and destination.exists():
        st.error('Output file already exists. Choose another filename to avoid overwriting it.')
    else:
        try:
            count, pages = merge_files(source, order, destination)
            st.success(f'Merged {count} files ({pages} pages) into: {destination}')
            with destination.open('rb') as f:
                st.download_button('Download merged PDF', data=f.read(), file_name=destination.name, mime='application/pdf')
        except Exception as exc:
            if destination and destination.exists():
                destination.unlink(missing_ok=True)
            st.error(f'Could not merge files: {exc}')

st.divider()
st.caption('Files stay on the machine where Streamlit runs. No upload to an external server is required when running locally.')
